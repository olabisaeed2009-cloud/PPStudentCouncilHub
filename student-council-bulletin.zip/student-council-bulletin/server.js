'use strict';
const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const config = require('./src/config');
const store = require('./src/db');
const sec = require('./src/security');
const v = require('./src/validate');
const { HttpError } = v;

const PUBLIC_DIR = path.join(__dirname, 'public');
const PRIVATE_DIR = path.join(__dirname, 'private');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
};

/* ---------- response helpers ---------- */

const SECURITY_HEADERS = {
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' https://fonts.googleapis.com",
    "font-src https://fonts.gstatic.com",
    "img-src 'self' data:",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; '),
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function json(res, status, data, headers = {}) {
  send(res, status, JSON.stringify(data), {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
}

function readJson(req, limit = 32 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooBig = false;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { tooBig = true; return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (tooBig) return reject(new HttpError(413, 'That request is too large.'));
      if (!chunks.length) return resolve({});
      try {
        const val = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (val === null || typeof val !== 'object' || Array.isArray(val)) throw new Error('shape');
        resolve(val);
      } catch {
        reject(new HttpError(400, 'Invalid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

/* ---------- static files ---------- */

async function serveFile(req, res, dir, relPath, { cache = 'no-cache' } = {}) {
  const abs = path.resolve(dir, '.' + path.sep + relPath);
  if (abs !== dir && !abs.startsWith(dir + path.sep)) return notFound(res);
  let stat;
  try { stat = await fsp.stat(abs); } catch { return notFound(res); }
  if (!stat.isFile()) return notFound(res);

  const etag = `"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  const headers = {
    'Content-Type': MIME[path.extname(abs).toLowerCase()] || 'application/octet-stream',
    'Cache-Control': cache,
    ETag: etag,
  };
  if (req.headers['if-none-match'] === etag) return send(res, 304, '', headers);
  headers['Content-Length'] = stat.size;
  res.writeHead(200, { ...SECURITY_HEADERS, ...headers });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(abs).pipe(res);
}

function notFound(res) {
  send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
}

/* ---------- auth guards ---------- */

function requireCouncil(req) {
  const session = sec.sessionFromRequest(req);
  if (!session) throw new HttpError(401, 'Please sign in with your Student Council account.');
  return session;
}
function requireAdmin(req) {
  const session = requireCouncil(req);
  if (session.user.role !== 'admin') throw new HttpError(403, 'Only Council admins can do that.');
  return session;
}

// Mutating requests must come from our own pages: a custom header (which browsers only allow
// same-origin, since we send no CORS headers) plus an Origin check.
function checkCsrf(req) {
  if (req.headers['x-requested-with'] !== 'fetch') throw new HttpError(403, 'Blocked: missing request header.');
  const origin = req.headers.origin;
  if (origin) {
    let host;
    try { host = new URL(origin).host; } catch { throw new HttpError(403, 'Blocked: bad origin.'); }
    const expected = String(req.headers['x-forwarded-host'] || req.headers.host || '');
    if (host !== req.headers.host && host !== expected) throw new HttpError(403, 'Blocked: cross-site request.');
  }
}

/* ---------- API ---------- */

const publicShape = ({ responder, ...r }) => r; // never leak which member wrote a response

const councilShape = (r) => r;

async function handleApi(req, res, url) {
  const { method } = req;
  const p = url.pathname;
  const secure = sec.isSecure(req);
  const ip = sec.clientIp(req);
  if (method !== 'GET' && method !== 'HEAD') checkCsrf(req);

  /* --- public: read the bulletin --- */
  if (method === 'GET' && p === '/api/requests') {
    const { filters, page } = v.parseListQuery(url);
    const out = store.listRequests(filters, page);
    return json(res, 200, { items: out.items.map(publicShape), total: out.total, counts: out.counts });
  }

  /* --- public: post a request --- */
  if (method === 'POST' && p === '/api/requests') {
    if (!sec.hit(`submit:${ip}`, 30, 10 * 60 * 1000)) throw new HttpError(429, 'Too many submissions from this network. Try again in a few minutes.');
    const body = await readJson(req);
    if (typeof body.website === 'string' && body.website.trim()) {
      // Honeypot field filled in: pretend it worked, store nothing.
      return json(res, 201, { item: { id: 0 } });
    }
    const item = store.createRequest(v.validateNewRequest(body));
    return json(res, 201, { item: publicShape(item) });
  }

  /* --- council: session --- */
  if (method === 'POST' && p === '/api/login') {
    const ipKey = `login-ip:${ip}`;
    if (!sec.allowed(ipKey, 10, 15 * 60 * 1000)) throw new HttpError(429, 'Too many sign-in attempts. Wait 15 minutes and try again.');
    const body = await readJson(req);
    const username = v.text(body.username).toLowerCase().slice(0, 64);
    const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
    const userKey = `login-user:${username}`;
    if (!sec.allowed(userKey, 10, 15 * 60 * 1000)) throw new HttpError(429, 'Too many sign-in attempts for this account. Wait 15 minutes and try again.');

    const user = username ? store.findUserByName(username) : null;
    const hash = user ? user.password_hash : await sec.getDummyHash();
    const ok = (await sec.verifyPassword(password, hash)) && !!user;
    if (!ok) {
      sec.hit(ipKey, 10, 15 * 60 * 1000);
      sec.hit(userKey, 10, 15 * 60 * 1000);
      throw new HttpError(401, 'Incorrect username or password.');
    }
    sec.reset(ipKey); sec.reset(userKey);
    const old = sec.parseCookies(req.headers.cookie)[sec.COOKIE];
    if (old) store.deleteSession(sec.sha256(old));
    const token = sec.createSession(user.id);
    return json(res, 200, { user: { id: user.id, username: user.username, display_name: user.display_name, role: user.role } },
      { 'Set-Cookie': sec.sessionCookie(token, secure) });
  }

  if (method === 'POST' && p === '/api/logout') {
    const token = sec.parseCookies(req.headers.cookie)[sec.COOKIE];
    if (token) store.deleteSession(sec.sha256(token));
    return json(res, 200, { ok: true }, { 'Set-Cookie': sec.clearCookie(secure) });
  }

  if (method === 'GET' && p === '/api/me') {
    const s = sec.sessionFromRequest(req);
    if (!s) return json(res, 401, { error: 'Not signed in.' });
    return json(res, 200, { user: s.user });
  }

  /* --- council: manage requests (every route re-checks the session) --- */
  if (method === 'GET' && p === '/api/council/requests') {
    requireCouncil(req);
    const { filters, page } = v.parseListQuery(url, { defaultLimit: 25, maxLimit: 100 });
    const out = store.listRequests(filters, page);
    return json(res, 200, { items: out.items.map(councilShape), total: out.total, counts: out.counts });
  }

  let m = p.match(/^\/api\/council\/requests\/(\d{1,12})$/);
  if (m) {
    const id = Number(m[1]);
    if (method === 'PATCH') {
      const { user } = requireCouncil(req);
      const changes = v.validateUpdate(await readJson(req));
      const item = store.updateRequest(id, changes, user.id);
      if (!item) throw new HttpError(404, 'That request no longer exists.');
      return json(res, 200, { item: councilShape(item) });
    }
    if (method === 'DELETE') {
      requireCouncil(req);
      if (!store.deleteRequest(id)) throw new HttpError(404, 'That request no longer exists.');
      return json(res, 200, { ok: true });
    }
  }

  /* --- council: account & members --- */
  if (method === 'POST' && p === '/api/council/password') {
    const { user, tokenHash } = requireCouncil(req);
    if (!sec.allowed(`pw:${user.id}`, 10, 15 * 60 * 1000)) throw new HttpError(429, 'Too many attempts. Try again later.');
    const body = await readJson(req);
    const record = store.findUserWithHash(user.id);
    const current = typeof body.current === 'string' ? body.current : '';
    if (!(await sec.verifyPassword(current, record.password_hash))) {
      sec.hit(`pw:${user.id}`, 10, 15 * 60 * 1000);
      throw new HttpError(422, 'Your current password is incorrect.', { current: 'Incorrect password.' });
    }
    const problem = v.passwordProblem(body.next);
    if (problem) throw new HttpError(422, problem, { next: problem });
    store.setPasswordHash(user.id, await sec.hashPassword(body.next));
    store.deleteUserSessions(user.id, tokenHash); // sign out everywhere else
    return json(res, 200, { ok: true });
  }

  if (p === '/api/council/members' && method === 'GET') {
    requireAdmin(req);
    return json(res, 200, { items: store.listUsers() });
  }
  if (p === '/api/council/members' && method === 'POST') {
    requireAdmin(req);
    const data = v.validateNewMember(await readJson(req));
    if (store.findUserByName(data.username)) throw new HttpError(422, 'That username is taken.', { username: 'That username is taken.' });
    const created = store.createUser({
      username: data.username, display_name: data.display_name, role: data.role,
      password_hash: await sec.hashPassword(data.password),
    });
    return json(res, 201, { item: created });
  }
  m = p.match(/^\/api\/council\/members\/(\d{1,12})$/);
  if (m && method === 'DELETE') {
    const { user } = requireAdmin(req);
    const id = Number(m[1]);
    if (id === user.id) throw new HttpError(400, "You can't remove your own account.");
    const target = store.findUserById(id);
    if (!target) throw new HttpError(404, 'That member no longer exists.');
    if (target.role === 'admin' && store.countAdmins() <= 1) throw new HttpError(400, 'At least one admin must remain.');
    store.deleteUser(id);
    return json(res, 200, { ok: true });
  }

  throw new HttpError(404, 'Not found.');
}

/* ---------- pages ---------- */

async function handlePage(req, res, url) {
  const p = url.pathname;

  if (p === '/healthz') return json(res, 200, { ok: true });

  // The dashboard's HTML and JavaScript are only ever sent to signed-in Council members.
  if (p === '/council' || p === '/council/') {
    const s = sec.sessionFromRequest(req);
    return serveFile(req, res, s ? PRIVATE_DIR : PUBLIC_DIR, s ? 'dashboard.html' : 'council-login.html',
      { cache: 'no-store' });
  }
  if (p === '/council/dashboard.js') {
    if (!sec.sessionFromRequest(req)) return send(res, 401, 'Sign in required', { 'Content-Type': 'text/plain; charset=utf-8' });
    return serveFile(req, res, PRIVATE_DIR, 'dashboard.js', { cache: 'no-store' });
  }

  let rel = decodeURIComponent(p);
  if (rel === '/') rel = '/index.html';
  return serveFile(req, res, PUBLIC_DIR, rel.slice(1));
}

/* ---------- server ---------- */

const server = http.createServer(async (req, res) => {
  try {
    if (!['GET', 'HEAD', 'POST', 'PATCH', 'DELETE'].includes(req.method)) {
      return send(res, 405, 'Method not allowed', { Allow: 'GET, HEAD, POST, PATCH, DELETE' });
    }
    const url = new URL(req.url, 'http://localhost');
    if (config.PROD && !sec.isSecure(req) && req.url !== '/healthz') {
      return send(res, 308, '', { Location: `https://${req.headers.host}${req.url}` });
    }
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    if (config.PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
    return await handlePage(req, res, url);
  } catch (err) {
    if (err instanceof HttpError) {
      return json(res, err.status, { error: err.message, fields: err.fields });
    }
    if (err instanceof URIError) return send(res, 400, 'Bad request');
    console.error(err);
    return json(res, 500, { error: 'Something went wrong on our end. Please try again.' });
  }
});
server.requestTimeout = 30_000;
server.headersTimeout = 15_000;

/* ---------- first-run: create the first Council admin from environment variables ---------- */

async function seedAdmin() {
  if (store.countUsers() > 0) return;
  const username = (process.env.COUNCIL_ADMIN_USERNAME || '').trim().toLowerCase();
  const password = process.env.COUNCIL_ADMIN_PASSWORD || '';
  if (!username || !password) {
    console.warn('\n[setup] No Council accounts exist yet. Create one with:  npm run create-council-user\n' +
      '        (or set COUNCIL_ADMIN_USERNAME and COUNCIL_ADMIN_PASSWORD before the first start)\n');
    return;
  }
  const problem = v.passwordProblem(password);
  if (problem || !/^[a-z0-9._-]{3,32}$/.test(username)) {
    console.error(`[setup] Could not create the first admin: ${problem || 'username must be 3–32 letters, numbers, . _ -'}`);
    return;
  }
  store.createUser({
    username, role: 'admin',
    display_name: (process.env.COUNCIL_ADMIN_NAME || 'Council Admin').trim().slice(0, 60),
    password_hash: await sec.hashPassword(password),
  });
  console.log(`[setup] Created first Council admin "${username}". Change the password after signing in.`);
}

if (require.main === module) {
  seedAdmin().then(() => {
    server.listen(config.PORT, config.HOST, () => {
      console.log(`Student Council Bulletin running on http://localhost:${config.PORT}`);
    });
  });
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.on(sig, () => server.close(() => process.exit(0)));
  }
}

module.exports = { server, seedAdmin };
