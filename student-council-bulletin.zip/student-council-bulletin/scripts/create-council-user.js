'use strict';
// Usage: npm run create-council-user
// Creates a Student Council account (the first one is made an admin). Passwords are hashed with scrypt.
const readline = require('node:readline');
const store = require('../src/db');
const sec = require('../src/security');
const v = require('../src/validate');

function ask(question, { hidden = false } = {}) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = (s) => { if (s.includes(question)) process.stdout.write(question); };
    }
    rl.question(question, (answer) => {
      rl.close();
      if (hidden) process.stdout.write('\n');
      resolve(answer);
    });
  });
}

(async () => {
  const first = store.countUsers() === 0;
  console.log(first ? 'No accounts yet: this one will be a Council admin.\n' : 'Adding a Council account.\n');
  const username = (process.env.NEW_USERNAME || (await ask('Username: '))).trim().toLowerCase();
  const display_name = (process.env.NEW_NAME || (await ask('Display name (e.g. Maya Patel): '))).trim();
  const password = process.env.NEW_PASSWORD || (await ask('Password (10+ characters): ', { hidden: true }));
  let role = first ? 'admin' : 'member';
  if (!first && !process.env.NEW_ROLE) {
    role = /^a/i.test(await ask('Role: admin or member? [member] ')) ? 'admin' : 'member';
  } else if (process.env.NEW_ROLE === 'admin') role = 'admin';

  try {
    const data = v.validateNewMember({ username, display_name, password, role });
    if (store.findUserByName(data.username)) throw new Error('That username is taken.');
    store.createUser({
      username: data.username, display_name: data.display_name, role: data.role,
      password_hash: await sec.hashPassword(data.password),
    });
    console.log(`\nCreated ${data.role} "${data.username}".`);
  } catch (err) {
    const detail = err.fields ? Object.values(err.fields).join(' ') : err.message;
    console.error(`\nCould not create account: ${detail}`);
    process.exitCode = 1;
  }
  process.exit();
})();
