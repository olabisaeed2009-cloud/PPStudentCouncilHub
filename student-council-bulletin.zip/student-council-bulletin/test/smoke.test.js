'use strict';
// End-to-end tests against the real server and a throwaway SQLite database.
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bulletin-'));
process.env.DATA_DIR = tmp;
process.env.DB_FILE = path.join(tmp, 'test.db');
process.env.COUNCIL_ADMIN_USERNAME = 'president';
process.env.COUNCIL_ADMIN_PASSWORD = 'correct-horse-battery';
process.env.COUNCIL_ADMIN_NAME = 'Maya Patel';

const { server, seedAdmin } = require('../server');
const store = require('../src/db');

let base;
const H = { 'X-Requested-With': 'fetch', 'Content-Type': 'application/json' };
async function call(method, url, { body, cookie, headers } = {}) {
  const res = await fetch(base + url, {
    method, redirect: 'manual',
    headers: { ...(method === 'GET' ? {} : H), ...(cookie ? { Cookie: cookie } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { /* html */ }
  return { status: res.status, json, text, res };
}
async function login(username, password) {
  const r = await call('POST', '/api/login', { body: { username, password } });
  const set = r.res.headers.get('set-cookie');
  return { ...r, cookie: set ? set.split(';')[0] : null, setCookie: set };
}

let passed = 0;
async function t(name, fn) {
  try { await fn(); passed++; console.log('  ok  ', name); }
  catch (e) { console.error('  FAIL', name, '\n      ', e.message); process.exitCode = 1; }
}

(async () => {
  await seedAdmin();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  const valid = { title: 'Water fountain broken', category: 'Facilities', description: 'The fountain by the gym has been dry all week.', priority: 'high', location: 'Gym hallway', student_name: 'Sam' };
  let id, adminCookie;

  await t('public pages load', async () => {
    const home = await call('GET', '/');
    assert.equal(home.status, 200);
    assert.match(home.text, /Student Council Bulletin/);
    assert.match(home.text, /Submit a Request/);
    assert.match(home.text, /Student Council Login/);
    assert.equal((await call('GET', '/styles.css')).status, 200);
    assert.match(home.res.headers.get('content-security-policy'), /script-src 'self'/);
  });

  await t('dashboard page and script are NOT served to the public', async () => {
    const page = await call('GET', '/council');
    assert.equal(page.status, 200);
    assert.match(page.text, /Student Council login/);
    assert.doesNotMatch(page.text, /Delete request|dashboard\.js/);
    assert.equal((await call('GET', '/council/dashboard.js')).status, 401);
    assert.equal((await call('GET', '/council/dashboard.html')).status, 404);
    assert.equal((await call('GET', '/dashboard.html')).status, 404);
    assert.equal((await call('GET', '/dashboard.js')).status, 404);
  });

  await t('students can submit; it is stored and listed', async () => {
    const r = await call('POST', '/api/requests', { body: valid });
    assert.equal(r.status, 201);
    id = r.json.item.id;
    assert.equal(r.json.item.status, 'submitted');
    assert.equal(r.json.item.responder, undefined);
    const list = await call('GET', '/api/requests');
    assert.equal(list.json.total, 1);
    assert.equal(list.json.items[0].title, valid.title);
    assert.equal(store.db.prepare('SELECT COUNT(*) n FROM requests').get().n, 1);
  });

  await t('validation rejects bad input', async () => {
    const r = await call('POST', '/api/requests', { body: { title: '', category: 'Nope', description: 'x' } });
    assert.equal(r.status, 422);
    assert.ok(r.json.fields.title && r.json.fields.category && r.json.fields.description);
    assert.equal((await call('POST', '/api/requests', { body: { ...valid, priority: 'urgent!!' } })).status, 422);
    assert.equal((await call('POST', '/api/requests', { body: { ...valid, title: 'x'.repeat(121) } })).status, 422);
  });

  await t('honeypot submissions are silently dropped', async () => {
    const r = await call('POST', '/api/requests', { body: { ...valid, website: 'http://spam' } });
    assert.equal(r.status, 201);
    assert.equal(store.db.prepare('SELECT COUNT(*) n FROM requests').get().n, 1);
  });

  await t('markup in requests is stored as plain text', async () => {
    const r = await call('POST', '/api/requests', { body: { ...valid, title: '<img src=x onerror=alert(1)>' } });
    assert.equal(r.json.item.title, '<img src=x onerror=alert(1)>');
    store.deleteRequest(r.json.item.id);
  });

  await t('CSRF protections block cross-site writes', async () => {
    const noHeader = await fetch(base + '/api/requests', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(valid) });
    assert.equal(noHeader.status, 403);
    const badOrigin = await call('POST', '/api/requests', { body: valid, headers: { Origin: 'https://evil.example' } });
    assert.equal(badOrigin.status, 403);
  });

  await t('unauthenticated users cannot use ANY council endpoint', async () => {
    assert.equal((await call('GET', '/api/council/requests')).status, 401);
    assert.equal((await call('PATCH', `/api/council/requests/${id}`, { body: { status: 'resolved' } })).status, 401);
    assert.equal((await call('DELETE', `/api/council/requests/${id}`)).status, 401);
    assert.equal((await call('GET', '/api/council/members')).status, 401);
    assert.equal((await call('POST', '/api/council/members', { body: { username: 'evil', display_name: 'x', password: 'password123456' } })).status, 401);
    assert.equal((await call('GET', '/api/me')).status, 401);
    // forged / guessed cookies
    for (const c of ['sc_session=admin', 'sc_session=' + 'A'.repeat(43), 'sc_session=1']) {
      assert.equal((await call('DELETE', `/api/council/requests/${id}`, { cookie: c })).status, 401);
    }
    assert.equal(store.getRequest(id).status, 'submitted');
  });

  await t('sign-in: wrong password rejected, right password sets a hardened cookie', async () => {
    const bad = await login('president', 'wrong-password-1');
    assert.equal(bad.status, 401);
    assert.equal(bad.cookie, null);
    assert.equal((await login('nobody', 'whatever-password')).status, 401);
    const ok = await login('PRESIDENT', 'correct-horse-battery'); // usernames are case-insensitive
    assert.equal(ok.status, 200);
    assert.match(ok.setCookie, /HttpOnly/);
    assert.match(ok.setCookie, /SameSite=Lax/);
    assert.equal(ok.json.user.password_hash, undefined);
    adminCookie = ok.cookie;
    // password is hashed at rest, and only a hash of the session token is stored
    const u = store.db.prepare('SELECT password_hash FROM users').get();
    assert.match(u.password_hash, /^scrypt\$/);
    assert.ok(!u.password_hash.includes('correct-horse'));
    const token = adminCookie.split('=')[1];
    assert.equal(store.db.prepare('SELECT COUNT(*) n FROM sessions WHERE token_hash = ?').get(token).n, 0);
  });

  await t('signed-in members get the dashboard', async () => {
    const page = await call('GET', '/council', { cookie: adminCookie });
    assert.match(page.text, /Council dashboard/);
    assert.match(page.text, /Are you sure you want to delete this request/);
    assert.equal((await call('GET', '/council/dashboard.js', { cookie: adminCookie })).status, 200);
    const me = await call('GET', '/api/me', { cookie: adminCookie });
    assert.equal(me.json.user.role, 'admin');
  });

  await t('council can search and filter', async () => {
    const all = await call('GET', '/api/council/requests', { cookie: adminCookie });
    assert.equal(all.json.total, 1);
    assert.equal((await call('GET', '/api/council/requests?q=fountain', { cookie: adminCookie })).json.total, 1);
    assert.equal((await call('GET', '/api/council/requests?q=zebra', { cookie: adminCookie })).json.total, 0);
    assert.equal((await call('GET', '/api/council/requests?category=Events', { cookie: adminCookie })).json.total, 0);
    assert.equal((await call('GET', '/api/council/requests?status=resolved', { cookie: adminCookie })).json.total, 0);
    assert.equal((await call('GET', "/api/requests?q=%25", {})).json.total, 0); // % is a literal, not a wildcard
    assert.equal(all.json.counts.submitted, 1);
  });

  await t('council can change status and add a response; the public sees it', async () => {
    const r = await call('PATCH', `/api/council/requests/${id}`, { cookie: adminCookie, body: { status: 'under_review', response: 'Thanks! Facilities has been notified.' } });
    assert.equal(r.status, 200);
    assert.equal(r.json.item.status, 'under_review');
    assert.equal(r.json.item.responder, 'Maya Patel');
    const pub = (await call('GET', '/api/requests')).json.items[0];
    assert.equal(pub.status, 'under_review');
    assert.equal(pub.response, 'Thanks! Facilities has been notified.');
    assert.equal(pub.responder, undefined); // members' names stay private
    assert.equal((await call('PATCH', `/api/council/requests/${id}`, { cookie: adminCookie, body: { status: 'bogus' } })).status, 422);
    assert.equal((await call('PATCH', `/api/council/requests/${id}`, { cookie: adminCookie, body: {} })).status, 400);
  });

  await t('mark as resolved sets and clears resolved_at', async () => {
    let r = await call('PATCH', `/api/council/requests/${id}`, { cookie: adminCookie, body: { status: 'resolved' } });
    assert.equal(r.json.item.status, 'resolved');
    assert.ok(r.json.item.resolved_at);
    r = await call('PATCH', `/api/council/requests/${id}`, { cookie: adminCookie, body: { status: 'under_review' } });
    assert.equal(r.json.item.resolved_at, null);
  });

  let memberCookie;
  await t('admins manage members; regular members are limited', async () => {
    const add = await call('POST', '/api/council/members', { cookie: adminCookie, body: { username: 'treasurer', display_name: 'Jo Kim', password: 'a-long-password-1', role: 'member' } });
    assert.equal(add.status, 201);
    assert.equal(add.json.item.password_hash, undefined);
    assert.equal((await call('POST', '/api/council/members', { cookie: adminCookie, body: { username: 'treasurer', display_name: 'Dup', password: 'a-long-password-1' } })).status, 422);
    assert.equal((await call('POST', '/api/council/members', { cookie: adminCookie, body: { username: 'short', display_name: 'S', password: 'tiny' } })).status, 422);
    const m = await login('treasurer', 'a-long-password-1');
    assert.equal(m.status, 200);
    memberCookie = m.cookie;
    assert.equal((await call('GET', '/api/council/requests', { cookie: memberCookie })).status, 200);
    assert.equal((await call('GET', '/api/council/members', { cookie: memberCookie })).status, 403);
    assert.equal((await call('POST', '/api/council/members', { cookie: memberCookie, body: { username: 'sneaky', display_name: 'S', password: 'a-long-password-1', role: 'admin' } })).status, 403);
    assert.equal((await call('DELETE', `/api/council/members/${add.json.item.id}`, { cookie: memberCookie })).status, 403);
  });

  await t('cannot remove yourself or the last admin', async () => {
    const me = (await call('GET', '/api/me', { cookie: adminCookie })).json.user;
    assert.equal((await call('DELETE', `/api/council/members/${me.id}`, { cookie: adminCookie })).status, 400);
  });

  await t('password change checks the current password and signs out other sessions', async () => {
    assert.equal((await call('POST', '/api/council/password', { cookie: memberCookie, body: { current: 'nope-nope-nope', next: 'brand-new-password' } })).status, 422);
    assert.equal((await call('POST', '/api/council/password', { cookie: memberCookie, body: { current: 'a-long-password-1', next: 'short' } })).status, 422);
    const other = await login('treasurer', 'a-long-password-1');
    const ok = await call('POST', '/api/council/password', { cookie: memberCookie, body: { current: 'a-long-password-1', next: 'brand-new-password' } });
    assert.equal(ok.status, 200);
    assert.equal((await call('GET', '/api/me', { cookie: other.cookie })).status, 401);
    assert.equal((await call('GET', '/api/me', { cookie: memberCookie })).status, 200);
    assert.equal((await login('treasurer', 'a-long-password-1')).status, 401);
    const again = await login('treasurer', 'brand-new-password');
    memberCookie = again.cookie;
    assert.equal(again.status, 200);
  });

  await t('deleting a request removes it from the database', async () => {
    assert.equal((await call('DELETE', `/api/council/requests/${id}`, { cookie: memberCookie })).status, 200);
    assert.equal(store.db.prepare('SELECT COUNT(*) n FROM requests WHERE id = ?').get(id).n, 0);
    assert.equal((await call('GET', '/api/requests')).json.total, 0);
    assert.equal((await call('DELETE', `/api/council/requests/${id}`, { cookie: memberCookie })).status, 404);
  });

  await t('signing out ends the session server-side', async () => {
    assert.equal((await call('POST', '/api/logout', { cookie: memberCookie })).status, 200);
    assert.equal((await call('GET', '/api/me', { cookie: memberCookie })).status, 401);
    assert.equal((await call('GET', '/council/dashboard.js', { cookie: memberCookie })).status, 401);
  });

  await t('expired sessions are rejected', async () => {
    store.db.prepare("UPDATE sessions SET expires_at = '2000-01-01T00:00:00.000Z'").run();
    assert.equal((await call('GET', '/api/me', { cookie: adminCookie })).status, 401);
  });

  await t('path traversal is blocked', async () => {
    for (const u of ['/..%2f..%2fserver.js', '/%2e%2e/server.js', '/../server.js', '/..%2fprivate%2fdashboard.js', '/%00']) {
      const r = await call('GET', u);
      assert.ok([400, 404].includes(r.status), `${u} -> ${r.status}`);
      assert.doesNotMatch(r.text, /require\(|DatabaseSync|Delete request/);
    }
  });

  await t('repeated bad logins are rate limited', async () => {
    let last;
    for (let i = 0; i < 12; i++) last = await login('president', 'wrong-password-' + i);
    assert.equal(last.status, 429);
    assert.equal((await login('president', 'correct-horse-battery')).status, 429);
  });

  server.close();
  console.log(`\n${passed} tests passed${process.exitCode ? ', with failures' : ''}`);
  fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(process.exitCode || 0);
})();
