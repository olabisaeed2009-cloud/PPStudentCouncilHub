(() => {
  const { h, api, slug, fmtDate, fmtDateTime, toast, debounce, backdropClose, showFieldErrors, CATEGORIES, STATUS_LABEL, PRIORITY_LABEL } = SC;
  const PAGE = 12;

  const $ = (id) => document.getElementById(id);
  const state = { q: '', category: '', status: '', offset: 0, total: 0, loading: false };

  /* ---------- filters ---------- */
  for (const c of CATEGORIES) {
    $('f-category').append(h('option', { value: c, text: c }));
    $('category').append(h('option', { value: c, text: c }));
  }
  const onFilter = debounce(() => {
    state.q = $('f-q').value.trim();
    state.category = $('f-category').value;
    state.status = $('f-status').value;
    load(true);
  }, 250);
  $('f-q').addEventListener('input', onFilter);
  $('f-category').addEventListener('change', onFilter);
  $('f-status').addEventListener('change', onFilter);

  /* ---------- cards ---------- */
  function card(r) {
    const meta = [h('span', { text: `Posted ${fmtDate(r.created_at)} by ${r.student_name || 'Anonymous'}` })];
    if (r.location) meta.push(h('span', { text: `Location: ${r.location}` }));
    return h('article', { class: 'note', 'data-cat': slug(r.category), 'data-id': r.id },
      h('div', { class: 'note-top' },
        h('span', { class: 'cat', text: r.category }),
        h('span', { class: 'prio' + (r.priority === 'high' ? ' prio-high' : ''), text: PRIORITY_LABEL[r.priority] })),
      h('h3', { class: 'note-title' }, h('button', { class: 'note-open', type: 'button', onclick: () => openDetail(r) }, r.title)),
      h('p', { class: 'note-desc', text: r.description }),
      h('div', { class: 'note-meta' }, meta),
      h('div', { class: 'note-foot' }, h('span', { class: `badge s-${r.status}`, text: STATUS_LABEL[r.status] })),
      r.response ? h('div', { class: 'reply' }, h('strong', { text: 'Student Council response' }), h('p', { text: r.response })) : null);
  }

  function openDetail(r) {
    const body = $('view-body');
    body.replaceChildren(
      h('div', { class: 'dialog-head' },
        h('h2', { id: 'view-title', text: r.title }),
        h('button', { class: 'x', type: 'button', 'aria-label': 'Close', onclick: () => $('view-dialog').close() }, '\u00d7')),
      h('p', { class: 'note-top' },
        h('span', { class: 'cat', 'data-cat': slug(r.category), text: r.category }),
        h('span', { class: `badge s-${r.status}`, text: STATUS_LABEL[r.status] })),
      h('p', { class: 'detail-text', text: r.description }),
      h('dl', { class: 'detail-list' },
        h('div', {}, h('dt', { text: 'Submitted' }), h('dd', { text: fmtDateTime(r.created_at) })),
        h('div', {}, h('dt', { text: 'From' }), h('dd', { text: r.student_name || 'Anonymous' })),
        r.location ? h('div', {}, h('dt', { text: 'Location' }), h('dd', { text: r.location })) : null,
        h('div', {}, h('dt', { text: 'Priority' }), h('dd', { text: PRIORITY_LABEL[r.priority] }))),
      r.response
        ? h('div', { class: 'reply full' }, h('strong', { text: `Student Council response \u2013 ${fmtDate(r.responded_at)}` }), h('p', { text: r.response }))
        : h('p', { class: 'hint detail-text', text: 'No Student Council response yet.' }),
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn btn-line', type: 'button', onclick: () => $('view-dialog').close() }, 'Close')));
    $('view-dialog').showModal();
  }
  backdropClose($('view-dialog'));

  /* ---------- loading ---------- */
  async function load(reset, highlightId) {
    if (state.loading) return;
    state.loading = true;
    if (reset) state.offset = 0;
    const params = new URLSearchParams({ limit: PAGE, offset: state.offset });
    for (const k of ['q', 'category', 'status']) if (state[k]) params.set(k, state[k]);
    try {
      const data = await api('/api/requests?' + params);
      const list = $('notes');
      if (reset) list.replaceChildren();
      list.querySelector('.empty')?.remove();
      for (const r of data.items) list.append(card(r));
      state.offset += data.items.length;
      state.total = data.total;

      const filtered = state.q || state.category || state.status;
      if (!data.total) {
        list.replaceChildren(h('div', { class: 'empty' },
          h('h3', { text: filtered ? 'No requests match those filters' : 'The board is empty' }),
          h('p', { text: filtered ? 'Try a different search or clear the filters.' : 'Be the first to post a problem, suggestion, or request.' }),
          filtered ? null : h('button', { class: 'btn btn-primary', type: 'button', onclick: openForm }, 'Submit a Request')));
      }
      $('count').textContent = data.total ? `Showing ${state.offset} of ${data.total} request${data.total === 1 ? '' : 's'}` : '';
      $('more').hidden = state.offset >= data.total;

      if (highlightId) {
        const el = list.querySelector(`[data-id="${highlightId}"]`);
        if (el) { el.classList.add('fresh'); el.scrollIntoView({ behavior: 'smooth', block: 'center' }); setTimeout(() => el.classList.remove('fresh'), 4000); }
      }
    } catch (err) {
      toast(err.message, true);
    } finally {
      state.loading = false;
    }
  }
  $('more').addEventListener('click', () => load(false));

  /* ---------- submit form ---------- */
  const dialog = $('form-dialog');
  const form = $('request-form');
  function openForm() { dialog.showModal(); $('title').focus(); }
  $('open-form').addEventListener('click', openForm);
  for (const b of dialog.querySelectorAll('[data-close]')) b.addEventListener('click', () => dialog.close());
  backdropClose(dialog);

  $('description').addEventListener('input', (e) => { $('desc-count').textContent = `${e.target.value.length} / 2000`; });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('submit-btn');
    const errBox = $('form-error');
    errBox.hidden = true;
    showFieldErrors(form, {});
    const fd = Object.fromEntries(new FormData(form));
    btn.disabled = true; btn.textContent = 'Posting\u2026';
    try {
      const { item } = await api('/api/requests', { method: 'POST', body: fd });
      form.reset();
      $('desc-count').textContent = '0 / 2000';
      dialog.close();
      // Clear filters so the new request is visible, then reload from the database.
      $('f-q').value = ''; $('f-category').value = ''; $('f-status').value = '';
      state.q = state.category = state.status = '';
      toast('Request posted to the bulletin.');
      document.getElementById('board').scrollIntoView({ behavior: 'smooth' });
      await load(true, item.id);
    } catch (err) {
      if (err.fields && Object.keys(err.fields).length) showFieldErrors(form, err.fields);
      else { errBox.textContent = err.message; errBox.hidden = false; }
    } finally {
      btn.disabled = false; btn.textContent = 'Post request';
    }
  });

  load(true);
})();
