(() => {
  const { api } = SC;
  const form = document.getElementById('login-form');
  const err = document.getElementById('login-error');
  const btn = document.getElementById('login-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    const { username, password } = form.elements;
    if (!username.value.trim() || !password.value) {
      err.textContent = 'Enter your username and password.';
      err.hidden = false;
      return;
    }
    btn.disabled = true; btn.textContent = 'Signing in\u2026';
    try {
      await api('/api/login', { method: 'POST', body: { username: username.value, password: password.value }, noRedirect: true });
      location.assign('/council'); // the server now sends the dashboard because we have a session
    } catch (e2) {
      err.textContent = e2.message;
      err.hidden = false;
      password.value = '';
      password.focus();
      btn.disabled = false; btn.textContent = 'Sign in';
    }
  });
})();
