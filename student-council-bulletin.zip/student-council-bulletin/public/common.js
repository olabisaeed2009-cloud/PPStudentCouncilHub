/* Shared helpers for every page. Never uses innerHTML, so user text can't inject markup. */
window.SC = (() => {
  const CATEGORIES = ['Facilities', 'Academics', 'Events', 'School Life', 'Technology', 'Other'];
  const STATUS_LABEL = { submitted: 'Submitted', under_review: 'Under review', resolved: 'Resolved' };
  const PRIORITY_LABEL = { low: 'Low priority', medium: 'Medium priority', high: 'High priority' };

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, val] of Object.entries(attrs || {})) {
      if (val === false || val == null) continue;
      if (k === 'class') el.className = val;
      else if (k === 'text') el.textContent = val;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), val);
      else el.setAttribute(k, val === true ? '' : val);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  async function api(path, { method = 'GET', body, noRedirect = false } = {}) {
    const res = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'fetch', ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) {
      if (res.status === 401 && !noRedirect && location.pathname.startsWith('/council')) {
        location.assign('/council');
      }
      const err = new Error(data.error || 'Something went wrong. Please try again.');
      err.status = res.status;
      err.fields = data.fields || {};
      throw err;
    }
    return data;
  }

  const slug = (s) => String(s).toLowerCase().replace(/\s+/g, '-');
  const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  const fmtDateTime = (iso) => new Date(iso).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });

  let toastTimer;
  function toast(message, bad = false) {
    let el = document.getElementById('toast');
    if (!el) { el = h('div', { id: 'toast', class: 'toast', role: 'status' }); document.body.append(el); }
    el.textContent = message;
    el.className = 'toast' + (bad ? ' bad' : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 4500);
  }

  function debounce(fn, ms) {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  }

  // Close a <dialog> when the dark backdrop is clicked.
  function backdropClose(dialog) {
    dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });
  }

  function showFieldErrors(form, fields) {
    for (const el of form.querySelectorAll('[data-err]')) el.textContent = '';
    for (const el of form.querySelectorAll('[aria-invalid]')) el.removeAttribute('aria-invalid');
    let first = null;
    for (const [name, msg] of Object.entries(fields || {})) {
      const holder = form.querySelector(`[data-err="${name}"]`);
      if (holder) holder.textContent = msg;
      const input = form.elements[name];
      const target = input && (input.nodeType ? input : input[0]);
      if (target) { target.setAttribute('aria-invalid', 'true'); first = first || target; }
    }
    if (first) first.focus();
  }

  return { CATEGORIES, STATUS_LABEL, PRIORITY_LABEL, h, api, slug, fmtDate, fmtDateTime, toast, debounce, backdropClose, showFieldErrors };
})();
