(() => {
  const { h, api, slug, fmtDate, fmtDateTime, toast, debounce, backdropClose, showFieldErrors, CATEGORIES, STATUS_LABEL, PRIORITY_LABEL } = SC;
  const $ = (id) => document.getElementById(id);
  const PAGE = 25;

  const state = { status: '', category: '', q: '', sort: 'newest', items: [], total: 0, counts: {}, selected: null, draft: null, me: null, loading: false };

  /* ---------- boot ---------- */
  for (const c of CATEGORIES) $('category').append(h('option', { value: c, text: c }));

  async function boot() {
    const { user } = await api('/api/me');
    state.me = user;
    $('who').textContent = `Signed in as ${user.display_name}`;
    $('btn-members').hidden = user.role !== 'admin';
    renderDetail();
    await load({ reset: true });
  }

  /* ---------- list ---------- */
  async function load({ reset = false, append = false } = {}) {
    if (state.loading) return;
    state.loading = true;
    const offset = append ? state.items.length : 0;
    const limit = append ? PAGE : Math.min(100, Math.max(PAGE, reset ? PAGE : state.items.length));
    const params = new URLSearchParams({ limit, offset, sort: state.sort });
    for (const k of ['q', 'category', 'status']) if (state[k]) params.set(k, state[k]);
    try {
      const data = await api('/api/council/requests?' + params);
      state.items = append ? state.items.concat(data.items) : data.items;
      state.total = data.total;
      state.counts = data.counts;
      if (state.selected) {
        const fresh = state.items.find((r) => r.id === state.selected.id);
        const cur = state.selected;
        const changed = fresh && (fresh.status !== cur.status || fresh.response !== cur.response || fresh.responded_at !== cur.responded_at);
        if (changed && !state.draft?.dirty) { state.selected = fresh; renderDetail(); }
      }
      renderList();
    } catch (err) {
      toast(err.message, true);
    } finally {
      state.loading = false;
    }
  }

  function renderList() {
    for (const k of ['all', 'submitted', 'under_review', 'resolved']) $('n-' + k).textContent = state.counts[k] ?? 0;
    for (const t of document.querySelectorAll('.tile')) t.setAttribute('aria-pressed', String(t.dataset.status === state.status));

    const rows = $('rows');
    rows.replaceChildren();
    if (!state.items.length) {
      const filtered = state.q || state.category || state.status;
      rows.append(h('li', { class: 'list-empty', text: filtered ? 'No requests match these filters.' : 'No requests yet. New ones will show up here.' }));
    }
    for (const r of state.items) {
      const selected = state.selected && state.selected.id === r.id;
      rows.append(h('li', {},
        h('button', { class: 'row', type: 'button', 'data-cat': slug(r.category), 'aria-current': selected ? 'true' : null, onclick: () => select(r) },
          h('span', { class: 'row-title', text: r.title }),
          h('span', { class: 'row-meta' },
            h('span', { class: 'cat', text: r.category }),
            h('span', { class: `badge s-${r.status}`, text: STATUS_LABEL[r.status] }),
            r.priority === 'high' ? h('span', { class: 'prio-high', text: 'High priority' }) : null,
            h('span', { text: fmtDate(r.created_at) }),
            r.response ? h('span', { class: 'replied', text: 'Replied' }) : null))));
    }
    $('count').textContent = state.total ? `Showing ${state.items.length} of ${state.total}` : '';
    $('more').hidden = state.items.length >= state.total;
  }

  /* ---------- filters ---------- */
  for (const t of document.querySelectorAll('.tile')) {
    t.addEventListener('click', () => { state.status = t.dataset.status; load({ reset: true }); });
  }
  $('q').addEventListener('input', debounce(() => { state.q = $('q').value.trim(); load({ reset: true }); }, 250));
  $('category').addEventListener('change', () => { state.category = $('category').value; load({ reset: true }); });
  $('sort').addEventListener('change', () => { state.sort = $('sort').value; load({ reset: true }); });
  $('refresh').addEventListener('click', () => load({}));
  $('more').addEventListener('click', () => load({ append: true }));

  /* ---------- detail ---------- */
  function select(r) {
    if (state.draft?.dirty && state.selected?.id !== r.id && !confirm('You have unsaved changes to this request. Discard them?')) return;
    state.selected = r;
    renderList();
    renderDetail();
    $('detail').classList.add('open');
    document.body.classList.add('detail-open');
    $('detail').scrollTop = 0;
  }

  function closeDetail() {
    if (state.draft?.dirty && !confirm('You have unsaved changes to this request. Discard them?')) return;
    state.selected = null; state.draft = null;
    $('detail').classList.remove('open');
    document.body.classList.remove('detail-open');
    renderList(); renderDetail();
  }

  function renderDetail() {
    const box = $('detail');
    const r = state.selected;
    if (!r) {
      state.draft = null;
      box.replaceChildren(h('p', { class: 'detail-empty', text: 'Select a request to read it, change its status, or reply.' }));
      return;
    }
    state.draft = { status: r.status, response: r.response, dirty: false };

    const status = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': 'Status' },
      Object.entries(STATUS_LABEL).map(([val, label]) =>
        h('label', {}, h('input', { type: 'radio', name: 'status', value: val, checked: val === r.status, onchange: () => { state.draft.status = val; markDirty(); } }), label)));

    const reply = h('textarea', { id: 'reply', maxlength: 2000, 'aria-describedby': 'reply-hint reply-count', oninput: (e) => { state.draft.response = e.target.value; $('reply-count').textContent = `${e.target.value.length} / 2000`; markDirty(); } });
    reply.value = r.response;

    const saveBtn = h('button', { class: 'btn btn-primary', type: 'button', id: 'save', disabled: true, onclick: () => save() }, 'Save changes');
    const resolveBtn = h('button', { class: 'btn btn-good', type: 'button', id: 'resolve', onclick: () => save({ status: 'resolved' }) }, 'Mark as resolved');
    if (r.status === 'resolved') resolveBtn.hidden = true;

    box.replaceChildren(
      h('div', { class: 'top' },
        h('button', { class: 'btn btn-line btn-small back', type: 'button', onclick: closeDetail }, '\u2190 All requests'),
        h('span', { class: 'cat', 'data-cat': slug(r.category), text: `${r.category} \u2013 request #${r.id}` })),
      h('h2', { text: r.title }),
      h('dl', { class: 'detail-list' },
        h('div', {}, h('dt', { text: 'Submitted' }), h('dd', { text: fmtDateTime(r.created_at) })),
        h('div', {}, h('dt', { text: 'From' }), h('dd', { text: r.student_name || 'Anonymous' })),
        r.location ? h('div', {}, h('dt', { text: 'Location' }), h('dd', { text: r.location })) : null,
        h('div', {}, h('dt', { text: 'Priority' }), h('dd', { text: PRIORITY_LABEL[r.priority] })),
        r.resolved_at ? h('div', {}, h('dt', { text: 'Resolved' }), h('dd', { text: fmtDateTime(r.resolved_at) })) : null,
        r.response && r.responder ? h('div', {}, h('dt', { text: 'Replied by' }), h('dd', { text: `${r.responder}, ${fmtDateTime(r.responded_at)}` })) : null),
      h('p', { class: 'detail-text', text: r.description }),

      h('div', { class: 'manage' },
        h('fieldset', {}, h('legend', { text: 'Status' }), status),
        h('div', { class: 'field' },
          h('label', { for: 'reply', text: 'Student Council response' }),
          reply,
          h('span', { class: 'hint', id: 'reply-hint', text: 'Public. Students see this on the bulletin card. Clear it to remove the response.' }),
          h('span', { class: 'hint', id: 'reply-count', text: `${r.response.length} / 2000` })),
        h('div', { class: 'actions' }, saveBtn, resolveBtn),
        h('p', { class: 'status-line', id: 'save-status', role: 'status' })),

      h('div', { class: 'danger-zone' },
        h('p', {}, h('strong', { text: 'Delete this request' }), 'Removes it permanently from the database, for example if it is spam or inappropriate.'),
        h('button', { class: 'btn btn-danger', type: 'button', id: 'delete', onclick: askDelete }, 'Delete request')));
  }

  function markDirty() {
    const r = state.selected;
    state.draft.dirty = state.draft.status !== r.status || state.draft.response.trim() !== r.response;
    $('save').disabled = !state.draft.dirty;
    $('save-status').textContent = '';
  }

  async function save(override = {}) {
    const r = state.selected;
    const body = {};
    const status = override.status ?? state.draft.status;
    if (status !== r.status) body.status = status;
    if (state.draft.response.trim() !== r.response) body.response = state.draft.response;
    if (!Object.keys(body).length) return;
    const line = $('save-status');
    $('save').disabled = true; $('resolve').disabled = true;
    line.className = 'status-line'; line.textContent = 'Saving\u2026';
    try {
      const { item } = await api(`/api/council/requests/${r.id}`, { method: 'PATCH', body });
      state.selected = item;
      state.draft.dirty = false;
      renderDetail();
      $('save-status').textContent = 'Saved.';
      await load({});
    } catch (err) {
      line.className = 'status-line bad';
      line.textContent = err.status === 404 ? 'That request was already deleted.' : err.message;
      $('save').disabled = false; $('resolve').disabled = false;
      if (err.status === 404) { state.selected = null; state.draft = null; renderDetail(); await load({}); }
    }
  }

  /* ---------- delete ---------- */
  const delDialog = $('delete-dialog');
  function askDelete() {
    $('delete-what').textContent = `\u201c${state.selected.title}\u201d`;
    $('delete-error').hidden = true;
    delDialog.showModal();
  }
  $('delete-cancel').addEventListener('click', () => delDialog.close());
  backdropClose(delDialog);
  $('delete-confirm').addEventListener('click', async () => {
    const r = state.selected;
    const btn = $('delete-confirm');
    btn.disabled = true; btn.textContent = 'Deleting\u2026';
    try {
      await api(`/api/council/requests/${r.id}`, { method: 'DELETE' });
      delDialog.close();
      state.selected = null; state.draft = null;
      $('detail').classList.remove('open');
      document.body.classList.remove('detail-open');
      renderDetail();
      toast('Request deleted.');
      await load({});
    } catch (err) {
      if (err.status === 404) { delDialog.close(); state.selected = null; renderDetail(); await load({}); return; }
      $('delete-error').textContent = err.message;
      $('delete-error').hidden = false;
    } finally {
      btn.disabled = false; btn.textContent = 'Delete request';
    }
  });

  /* ---------- account ---------- */
  for (const d of document.querySelectorAll('dialog')) for (const b of d.querySelectorAll('[data-close]')) b.addEventListener('click', () => d.close());
  backdropClose($('account-dialog')); backdropClose($('members-dialog'));

  $('btn-logout').addEventListener('click', async () => {
    try { await api('/api/logout', { method: 'POST', noRedirect: true }); } finally { location.assign('/council'); }
  });

  $('btn-account').addEventListener('click', () => {
    $('account-form').reset(); $('account-error').hidden = true; $('account-ok').hidden = true;
    showFieldErrors($('account-form'), {});
    $('account-dialog').showModal();
  });
  $('account-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    $('account-error').hidden = true; $('account-ok').hidden = true; showFieldErrors(f, {});
    try {
      await api('/api/council/password', { method: 'POST', body: { current: f.elements.current.value, next: f.elements.next.value } });
      f.reset(); $('account-ok').hidden = false;
    } catch (err) {
      if (Object.keys(err.fields).length) showFieldErrors(f, err.fields);
      else { $('account-error').textContent = err.message; $('account-error').hidden = false; }
    }
  });

  /* ---------- members (admins) ---------- */
  async function loadMembers() {
    const { items } = await api('/api/council/members');
    $('member-list').replaceChildren(...items.map((m) =>
      h('li', {},
        h('span', {}, h('strong', { text: m.display_name }), h('span', { class: 'role', text: m.role === 'admin' ? 'Admin' : 'Member' }), h('small', { text: m.username })),
        m.id === state.me.id
          ? h('span', { class: 'hint', text: 'You' })
          : h('button', { class: 'btn btn-danger btn-small', type: 'button', onclick: () => removeMember(m) }, 'Remove'))));
  }
  async function removeMember(m) {
    if (!confirm(`Remove ${m.display_name} (${m.username})? They will be signed out and lose access.`)) return;
    try { await api(`/api/council/members/${m.id}`, { method: 'DELETE' }); toast('Member removed.'); await loadMembers(); }
    catch (err) { toast(err.message, true); }
  }
  $('btn-members').addEventListener('click', async () => {
    $('member-form').reset(); $('member-error').hidden = true; showFieldErrors($('member-form'), {});
    try { await loadMembers(); $('members-dialog').showModal(); } catch (err) { toast(err.message, true); }
  });
  $('member-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    $('member-error').hidden = true; showFieldErrors(f, {});
    try {
      await api('/api/council/members', { method: 'POST', body: Object.fromEntries(new FormData(f)) });
      f.reset(); toast('Member added.'); await loadMembers();
    } catch (err) {
      if (Object.keys(err.fields).length) showFieldErrors(f, err.fields);
      else { $('member-error').textContent = err.message; $('member-error').hidden = false; }
    }
  });

  window.addEventListener('beforeunload', (e) => { if (state.draft?.dirty) { e.preventDefault(); e.returnValue = ''; } });

  boot().catch((err) => toast(err.message, true));
})();
