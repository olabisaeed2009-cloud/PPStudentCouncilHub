'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const config = require('./config');
const store = require('./db');

const scrypt = promisify(crypto.scrypt);
const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

/* ---------- passwords (scrypt, per-user random salt) ---------- */

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64'), key.toString('base64')].join('$');
}

async function verifyPassword(password, stored) {
  const [scheme, N, r, p, saltB64, keyB64] = String(stored).split('$');
  if (scheme !== 'scrypt') return false;
  const expected = Buffer.from(keyB64, 'base64');
  const actual = await scrypt(password, Buffer.from(saltB64, 'base64'), expected.length, {
    N: Number(N), r: Number(r), p: Number(p),
  });
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

// Compared against when the username does not exist, so response time doesn't reveal valid usernames.
let dummyHash;
const getDummyHash = async () => (dummyHash ||= await hashPassword(crypto.randomBytes(12).toString('hex')));

/* ---------- sessions (random token in an HttpOnly cookie; only its hash is stored) ---------- */

const COOKIE = 'sc_session';
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const expiryFromNow = () => new Date(Date.now() + config.SESSION_HOURS * 3600 * 1000).toISOString();

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) {
      try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore bad cookie */ }
    }
  }
  return out;
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  store.insertSession(sha256(token), userId, expiryFromNow());
  return token;
}

function sessionFromRequest(req) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (!token || token.length > 100) return null;
  const hash = sha256(token);
  const row = store.findSession(hash);
  if (!row) return null;
  const remaining = new Date(row.expires_at).getTime() - Date.now();
  if (remaining <= 0) { store.deleteSession(hash); return null; }
  // Sliding expiry: refresh once more than an hour of the window has been used.
  if (remaining < (config.SESSION_HOURS - 1) * 3600 * 1000) store.touchSession(hash, expiryFromNow());
  return { tokenHash: hash, user: { id: row.id, username: row.username, display_name: row.display_name, role: row.role } };
}

function cookieHeader(value, secure, maxAgeSeconds) {
  return [
    `${COOKIE}=${value}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSeconds}`,
    secure ? 'Secure' : '',
  ].filter(Boolean).join('; ');
}
const sessionCookie = (token, secure) => cookieHeader(token, secure, config.SESSION_HOURS * 3600);
const clearCookie = (secure) => cookieHeader('', secure, 0);

/* ---------- rate limiting (in memory, sliding window) ---------- */

const buckets = new Map();
function hit(key, max, windowMs) {
  const t = Date.now();
  const arr = (buckets.get(key) || []).filter((x) => t - x < windowMs);
  arr.push(t);
  buckets.set(key, arr);
  return arr.length <= max;
}
function allowed(key, max, windowMs) {
  const t = Date.now();
  return (buckets.get(key) || []).filter((x) => t - x < windowMs).length < max;
}
function reset(key) { buckets.delete(key); }
setInterval(() => {
  const t = Date.now();
  for (const [k, arr] of buckets) {
    const fresh = arr.filter((x) => t - x < 3600 * 1000);
    if (fresh.length) buckets.set(k, fresh); else buckets.delete(k);
  }
  store.purgeExpiredSessions();
}, 10 * 60 * 1000).unref();

/* ---------- request helpers ---------- */

function clientIp(req) {
  if (config.TRUST_PROXY) {
    if (config.CLIENT_IP_HEADER && req.headers[config.CLIENT_IP_HEADER]) {
      return String(req.headers[config.CLIENT_IP_HEADER]).split(',')[0].trim();
    }
    const parts = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
    if (parts.length) return parts[Math.max(0, parts.length - config.TRUST_PROXY_HOPS)];
  }
  return req.socket.remoteAddress || 'unknown';
}

function isSecure(req) {
  if (req.socket.encrypted) return true;
  return config.TRUST_PROXY && String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';
}

module.exports = {
  hashPassword, verifyPassword, getDummyHash,
  createSession, sessionFromRequest, sessionCookie, clearCookie, sha256, parseCookies, COOKIE,
  hit, allowed, reset, clientIp, isSecure,
};
