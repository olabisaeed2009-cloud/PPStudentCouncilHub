'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

fs.mkdirSync(config.DATA_DIR, { recursive: true });
const file = process.env.DB_FILE || path.join(config.DATA_DIR, 'bulletin.db');
const db = new DatabaseSync(file);

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  PRAGMA busy_timeout = 5000;

  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    display_name  TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
    created_at    TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

  CREATE TABLE IF NOT EXISTS requests (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    title        TEXT NOT NULL,
    category     TEXT NOT NULL CHECK (category IN ('Facilities','Academics','Events','School Life','Technology','Other')),
    description  TEXT NOT NULL,
    location     TEXT NOT NULL DEFAULT '',
    priority     TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
    student_name TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','under_review','resolved')),
    response     TEXT NOT NULL DEFAULT '',
    responded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    responded_at TEXT,
    resolved_at  TEXT,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_requests_created  ON requests(created_at);
  CREATE INDEX IF NOT EXISTS idx_requests_status   ON requests(status);
  CREATE INDEX IF NOT EXISTS idx_requests_category ON requests(category);
`);

const now = () => new Date().toISOString();

/* ---------- requests ---------- */

const PUBLIC_COLUMNS = `r.id, r.title, r.category, r.description, r.location, r.priority,
  r.student_name, r.status, r.response, r.responded_at, r.resolved_at, r.created_at`;

function escapeLike(s) {
  return s.replace(/[\\%_]/g, (c) => '\\' + c);
}

function buildWhere({ q, category, status }, { ignoreStatus = false } = {}) {
  const where = [];
  const params = [];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    where.push(`(r.title LIKE ? ESCAPE '\\' OR r.description LIKE ? ESCAPE '\\' OR r.location LIKE ? ESCAPE '\\' OR r.student_name LIKE ? ESCAPE '\\')`);
    params.push(like, like, like, like);
  }
  if (category) { where.push('r.category = ?'); params.push(category); }
  if (status && !ignoreStatus) { where.push('r.status = ?'); params.push(status); }
  return { sql: where.length ? 'WHERE ' + where.join(' AND ') : '', params };
}

const ORDERS = {
  newest: 'r.created_at DESC, r.id DESC',
  oldest: 'r.created_at ASC, r.id ASC',
  priority: "CASE r.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, r.created_at DESC, r.id DESC",
};

function listRequests(filters, { limit, offset, sort }) {
  const w = buildWhere(filters);
  const order = ORDERS[sort] || ORDERS.newest;
  const items = db
    .prepare(`SELECT ${PUBLIC_COLUMNS}, u.display_name AS responder
              FROM requests r LEFT JOIN users u ON u.id = r.responded_by
              ${w.sql} ORDER BY ${order} LIMIT ? OFFSET ?`)
    .all(...w.params, limit, offset);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM requests r ${w.sql}`).get(...w.params).n;

  const wc = buildWhere(filters, { ignoreStatus: true });
  const rows = db
    .prepare(`SELECT r.status AS status, COUNT(*) AS n FROM requests r ${wc.sql} GROUP BY r.status`)
    .all(...wc.params);
  const counts = { submitted: 0, under_review: 0, resolved: 0 };
  for (const row of rows) counts[row.status] = row.n;
  counts.all = counts.submitted + counts.under_review + counts.resolved;

  return { items, total, counts };
}

function getRequest(id) {
  return db
    .prepare(`SELECT ${PUBLIC_COLUMNS}, u.display_name AS responder
              FROM requests r LEFT JOIN users u ON u.id = r.responded_by WHERE r.id = ?`)
    .get(id);
}

function createRequest(r) {
  const t = now();
  const info = db
    .prepare(`INSERT INTO requests (title, category, description, location, priority, student_name, status, created_at, updated_at)
              VALUES (?, ?, ?, ?, ?, ?, 'submitted', ?, ?)`)
    .run(r.title, r.category, r.description, r.location, r.priority, r.student_name, t, t);
  return getRequest(Number(info.lastInsertRowid));
}

function updateRequest(id, changes, userId) {
  const current = getRequest(id);
  if (!current) return null;
  const t = now();
  const next = { status: current.status, response: current.response, responded_at: current.responded_at, resolved_at: current.resolved_at };
  let responder;

  if (changes.status !== undefined && changes.status !== current.status) {
    next.status = changes.status;
    next.resolved_at = changes.status === 'resolved' ? t : null;
  }
  if (changes.response !== undefined && changes.response !== current.response) {
    next.response = changes.response;
    next.responded_at = changes.response ? t : null;
    responder = changes.response ? userId : null;
  }
  if (responder !== undefined) {
    db.prepare(`UPDATE requests SET status=?, response=?, responded_at=?, resolved_at=?, responded_by=?, updated_at=? WHERE id=?`)
      .run(next.status, next.response, next.responded_at, next.resolved_at, responder, t, id);
  } else {
    db.prepare(`UPDATE requests SET status=?, response=?, responded_at=?, resolved_at=?, updated_at=? WHERE id=?`)
      .run(next.status, next.response, next.responded_at, next.resolved_at, t, id);
  }
  return getRequest(id);
}

function deleteRequest(id) {
  return db.prepare('DELETE FROM requests WHERE id = ?').run(id).changes > 0;
}

/* ---------- users & sessions ---------- */

const userCols = 'id, username, display_name, role, created_at';

const findUserByName = (username) => db.prepare('SELECT * FROM users WHERE username = ?').get(username);
const findUserById = (id) => db.prepare(`SELECT ${userCols} FROM users WHERE id = ?`).get(id);
const findUserWithHash = (id) => db.prepare('SELECT * FROM users WHERE id = ?').get(id);
const listUsers = () => db.prepare(`SELECT ${userCols} FROM users ORDER BY created_at ASC`).all();
const countUsers = () => db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
const countAdmins = () => db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'").get().n;

function createUser({ username, display_name, password_hash, role }) {
  const info = db
    .prepare('INSERT INTO users (username, display_name, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(username, display_name, password_hash, role, now());
  return findUserById(Number(info.lastInsertRowid));
}

const deleteUser = (id) => db.prepare('DELETE FROM users WHERE id = ?').run(id).changes > 0;
const setPasswordHash = (id, hash) => db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, id);

function insertSession(tokenHash, userId, expiresAt) {
  db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
    .run(tokenHash, userId, now(), expiresAt);
}
function findSession(tokenHash) {
  return db
    .prepare(`SELECT s.expires_at, u.id, u.username, u.display_name, u.role
              FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`)
    .get(tokenHash);
}
const touchSession = (tokenHash, expiresAt) =>
  db.prepare('UPDATE sessions SET expires_at = ? WHERE token_hash = ?').run(expiresAt, tokenHash);
const deleteSession = (tokenHash) => db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
const deleteUserSessions = (userId, exceptHash) =>
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash IS NOT ?').run(userId, exceptHash || null);
const purgeExpiredSessions = () => db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now());

module.exports = {
  db, now,
  listRequests, getRequest, createRequest, updateRequest, deleteRequest,
  findUserByName, findUserById, findUserWithHash, listUsers, countUsers, countAdmins, createUser, deleteUser, setPasswordHash,
  insertSession, findSession, touchSession, deleteSession, deleteUserSessions, purgeExpiredSessions,
};
