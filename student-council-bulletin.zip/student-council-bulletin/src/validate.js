'use strict';
const config = require('./config');
const { LIMITS } = config;

class HttpError extends Error {
  constructor(status, message, fields) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

// Strip control characters; keep newlines only for multi-line fields.
function text(value, { multiline = false } = {}) {
  if (typeof value !== 'string') return '';
  let s = value.normalize('NFC').replace(/\r\n?/g, '\n');
  s = s.replace(multiline ? /[\u0000-\u0009\u000B-\u001F\u007F]/g : /[\u0000-\u001F\u007F]/g, multiline ? '' : ' ');
  if (!multiline) s = s.replace(/\s+/g, ' ');
  return s.trim();
}

function validateNewRequest(body) {
  const errors = {};
  const title = text(body.title);
  const description = text(body.description, { multiline: true });
  const location = text(body.location);
  const student_name = text(body.student_name);
  const category = typeof body.category === 'string' ? body.category : '';
  const priority = typeof body.priority === 'string' && body.priority ? body.priority : 'medium';

  if (!title) errors.title = 'Add a short title.';
  else if (title.length > LIMITS.title) errors.title = `Keep the title under ${LIMITS.title} characters.`;
  if (!config.CATEGORIES.includes(category)) errors.category = 'Choose a category.';
  if (!description) errors.description = 'Describe the problem or idea.';
  else if (description.length < 10) errors.description = 'Add a little more detail (at least 10 characters).';
  else if (description.length > LIMITS.description) errors.description = `Keep the description under ${LIMITS.description} characters.`;
  if (location.length > LIMITS.location) errors.location = `Keep the location under ${LIMITS.location} characters.`;
  if (student_name.length > LIMITS.name) errors.student_name = `Keep the name under ${LIMITS.name} characters.`;
  if (!config.PRIORITIES.includes(priority)) errors.priority = 'Choose a priority.';

  if (Object.keys(errors).length) throw new HttpError(422, 'Please fix the highlighted fields.', errors);
  return { title, category, description, location, priority, student_name };
}

function validateUpdate(body) {
  const changes = {};
  const errors = {};
  if (body.status !== undefined) {
    if (!config.STATUSES.includes(body.status)) errors.status = 'Unknown status.';
    else changes.status = body.status;
  }
  if (body.response !== undefined) {
    if (typeof body.response !== 'string') errors.response = 'Response must be text.';
    else {
      const r = text(body.response, { multiline: true });
      if (r.length > LIMITS.response) errors.response = `Keep the response under ${LIMITS.response} characters.`;
      else changes.response = r;
    }
  }
  if (Object.keys(errors).length) throw new HttpError(422, 'Please fix the highlighted fields.', errors);
  if (!Object.keys(changes).length) throw new HttpError(400, 'Nothing to update.');
  return changes;
}

function validateNewMember(body) {
  const errors = {};
  const username = text(body.username).toLowerCase();
  const display_name = text(body.display_name);
  const password = typeof body.password === 'string' ? body.password : '';
  const role = body.role === 'admin' ? 'admin' : 'member';

  if (!/^[a-z0-9._-]{3,32}$/.test(username)) errors.username = 'Use 3–32 letters, numbers, dots, dashes or underscores.';
  if (!display_name || display_name.length > 60) errors.display_name = 'Add a name (up to 60 characters).';
  const pwError = passwordProblem(password);
  if (pwError) errors.password = pwError;
  if (Object.keys(errors).length) throw new HttpError(422, 'Please fix the highlighted fields.', errors);
  return { username, display_name, password, role };
}

function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < config.MIN_PASSWORD_LENGTH)
    return `Use at least ${config.MIN_PASSWORD_LENGTH} characters.`;
  if (pw.length > 200) return 'That password is too long.';
  return null;
}

function parseListQuery(url, { defaultLimit = 12, maxLimit = 50 } = {}) {
  const p = url.searchParams;
  const category = p.get('category') || '';
  const status = p.get('status') || '';
  const sort = p.get('sort') || 'newest';
  const q = text(p.get('q') || '').slice(0, 100);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(p.get('limit'), 10) || defaultLimit));
  const offset = Math.max(0, parseInt(p.get('offset'), 10) || 0);
  return {
    filters: {
      q,
      category: config.CATEGORIES.includes(category) ? category : '',
      status: config.STATUSES.includes(status) ? status : '',
    },
    page: { limit, offset, sort },
  };
}

module.exports = { HttpError, text, validateNewRequest, validateUpdate, validateNewMember, passwordProblem, parseListQuery };
