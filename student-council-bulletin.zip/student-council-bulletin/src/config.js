'use strict';
const path = require('node:path');

const PROD = process.env.NODE_ENV === 'production';

module.exports = {
  PROD,
  PORT: Number(process.env.PORT) || 3000,
  HOST: process.env.HOST || '0.0.0.0',
  DATA_DIR: process.env.DATA_DIR || path.join(__dirname, '..', 'data'),

  // Set TRUST_PROXY=1 when running behind a load balancer (Render, Fly, Railway...).
  // It defaults to on in production because those platforms always sit behind one.
  TRUST_PROXY: process.env.TRUST_PROXY ? process.env.TRUST_PROXY === '1' : PROD,
  // Number of proxies between the internet and this server (used for X-Forwarded-For).
  TRUST_PROXY_HOPS: Math.max(1, Number(process.env.TRUST_PROXY_HOPS) || 1),
  // Optional: a header your host guarantees to be the real client IP (e.g. fly-client-ip).
  CLIENT_IP_HEADER: (process.env.CLIENT_IP_HEADER || '').toLowerCase(),

  SESSION_HOURS: 12,
  MIN_PASSWORD_LENGTH: 10,

  CATEGORIES: ['Facilities', 'Academics', 'Events', 'School Life', 'Technology', 'Other'],
  STATUSES: ['submitted', 'under_review', 'resolved'],
  PRIORITIES: ['low', 'medium', 'high'],

  LIMITS: { title: 120, description: 2000, location: 100, name: 60, response: 2000 },
};
