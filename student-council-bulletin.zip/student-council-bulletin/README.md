# Student Council Bulletin

A digital request board. Students post problems, suggestions, and requests; the Student Council reviews, replies, resolves, or deletes them from a members-only dashboard.

- **Backend:** Node.js 22+ (no npm dependencies) with a built-in SQLite database.
- **Frontend:** plain HTML/CSS/JS, responsive, no build step.
- **Auth:** Council accounts, scrypt-hashed passwords, server-side sessions in an HttpOnly cookie.

## Run it locally

```bash
node -v                        # needs 22.13 or newer
npm run create-council-user    # creates the first Council admin (asks for a password)
npm start                      # http://localhost:3000
npm test                       # 21 end-to-end tests against a throwaway database
```

Pages: `/` (bulletin), `/council` (login; becomes the dashboard once signed in).

## Deploy (get a public URL)

SQLite is a file, so the host **must give the app a persistent disk**. Free tiers with temporary disks will lose every request on restart. Run **one** instance only.

### Render (easiest; needs a paid instance because of the disk)
1. Push this folder to a GitHub repo.
2. Render → **New → Blueprint** → pick the repo (it reads `render.yaml`).
3. When prompted, enter `COUNCIL_ADMIN_USERNAME`, `COUNCIL_ADMIN_PASSWORD` (10+ chars), and `COUNCIL_ADMIN_NAME`.
4. Open the `onrender.com` URL. Sign in at `/council`, then use **Account** to change the password and **Members** to add the other Council members.

### Fly.io
```bash
fly launch --no-deploy --copy-config     # pick your own app name
fly volumes create bulletin_data --size 1
fly secrets set COUNCIL_ADMIN_USERNAME=president COUNCIL_ADMIN_PASSWORD='a long passphrase' COUNCIL_ADMIN_NAME='Council President'
fly deploy
```

### Any Docker host
`docker build -t bulletin . && docker run -p 3000:3000 -v bulletin_data:/data -e COUNCIL_ADMIN_USERNAME=... -e COUNCIL_ADMIN_PASSWORD=... bulletin`

The first-admin variables are only used when no accounts exist. After signing in you can delete them from the host's settings.

## How access is protected

| Layer | What it does |
| --- | --- |
| Every Council API route | Checks the session on the **server** on every call. No session → `401`. Members-only actions (status, reply, delete) can't be reached by students no matter what they do in the browser. |
| Admin-only routes | Adding/removing members returns `403` for non-admins. |
| Dashboard files | `/council` sends the dashboard HTML and `dashboard.js` **only** to signed-in members; everyone else gets the login page (or `401` for the script). |
| Passwords | scrypt with a random salt per user; never sent to the frontend; constant-time comparison. |
| Sessions | 256-bit random token in an `HttpOnly`, `SameSite=Lax`, `Secure` (on HTTPS) cookie. Only a hash of the token is stored. 12-hour sliding expiry. Sign out and password change revoke sessions. |
| Brute force | Sign-in attempts are limited per IP and per username. |
| Abuse | Submission rate limit and a hidden honeypot field. Council can delete anything. |
| Injection | All database access uses parameterized queries. The frontend renders user text with `textContent` (never `innerHTML`), and a strict Content-Security-Policy is set. |
| Cross-site requests | Writes require a custom header and a matching `Origin`. |
| Deletion | `DELETE` really removes the row. The dashboard asks for confirmation first. |

## Things to know

- **Requests are public.** Names only appear if the student typed one. Council members' names are not shown publicly (replies show as "Student Council").
- **No email notifications and no moderation queue.** Posts appear immediately; the Council removes anything inappropriate with **Delete request**.
- **Backups:** copy `bulletin.db` (plus `-wal`/`-shm` if present) from the data disk now and then. Render and Fly both offer disk snapshots.
- **Lost the only admin password?** Run `npm run create-council-user` in the host's shell to add another admin.
- **Behind a CDN/extra proxy?** Set `TRUST_PROXY_HOPS` (or `CLIENT_IP_HEADER`) so rate limits see real visitor IPs.
- The deployment files (`render.yaml`, `fly.toml`, `Dockerfile`) were written to each platform's documented format but couldn't be test-deployed from the build environment. The app itself has been tested locally, in a real browser, end to end.

## Project layout

```
server.js            HTTP server, API routes, auth guards, static files
src/db.js            SQLite schema and queries (parameterized)
src/security.js      password hashing, sessions, rate limiting
src/validate.js      input validation
public/              student-facing pages + shared CSS/JS
private/             dashboard HTML/JS (served only to signed-in members)
scripts/             create-council-user.js
test/smoke.test.js   end-to-end tests
```
